@echo off
title Inventario Smith - Tecnitrauma (modo local)
cd /d "%~dp0"
echo No cierre esta ventana mientras use la aplicacion.
python -m streamlit run app.py --server.address 0.0.0.0
pause
