@echo off
title Instalacion de librerias
cd /d "%~dp0"
python -m pip install streamlit pandas openpyxl xlsxwriter plotly jinja2 sqlalchemy
echo.
echo Listo. Ahora doble clic en INICIAR_APP.bat
pause
